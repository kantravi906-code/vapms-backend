# VAPMS Backend

Real REST API + PostgreSQL backend for the Vehicle Access Pass Management System.
Every user signs in with a username/password verified server-side (bcrypt hashes, JWT
sessions), and Block/Blacklist actions are enforced server-side as Security-HOD-only —
this is what the frontend demo (`VAPMS.jsx`) was missing.

## 1. Local setup

```bash
# 1. Start Postgres (or point DATABASE_URL at any Postgres you already have)
docker compose up -d

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# edit .env — at minimum set JWT_SECRET to a long random string

# 4. Create the schema
npm run migrate

# 5. Seed demo users + master data (one account per role — see console output for
#    username/password pairs, or check src/scripts/seed.js)
npm run seed

# 6. Start the API
npm run dev      # with auto-restart, or
npm start         # plain node
```

The API listens on `http://localhost:4000` by default. Check it's alive:

```bash
curl http://localhost:4000/api/health
```

## 2. Authentication

```
POST /api/auth/login
Body: { "username": "vikram.rao", "password": "security123" }
Response: { "token": "...", "user": { "id", "name", "role", ... } }
```

Send the token on every subsequent request:

```
Authorization: Bearer <token>
```

`GET /api/auth/me` returns the current user for the token. Tokens expire after
`JWT_EXPIRES_IN` (default 12h) — the frontend should redirect to login on a 401.

## 3. API overview

| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/login`, `GET /api/auth/me`, `POST /api/auth/logout` |
| Users (Admin only) | `GET/POST /api/users`, `PATCH /api/users/:id/status`, `POST /api/users/:id/change-password` |
| Masters | `GET /api/masters`, `POST/DELETE /api/masters/:type` (department/contractor/company/vehicle_type) |
| Vehicles | `GET/POST /api/vehicles`, `GET /api/vehicles/:id`, `POST /api/vehicles/:id/photo`, `POST /api/vehicles/:id/documents/:docType/file` |
| Drivers | same shape as Vehicles, under `/api/drivers` |
| Approvals | `GET /api/approvals/:entityType/queue`, `POST /api/approvals/:entityType/:id/decision` (`{action, remarks}`), `POST /api/approvals/:entityType/:id/resubmit` — `entityType` is `vehicle` or `driver` |
| Passes | `GET /api/passes`, `GET /api/passes/:id/qr.png` (real scannable QR) |
| Gate / QR | `POST /api/gate/scan` (`{query}`), `POST /api/gate/log` (`{vehicleNumber, type}`), `GET /api/gate/scans`, `GET /api/gate/logs` |
| Block / Blacklist | `POST /api/blocklist/vehicles/:id/block` \| `/unblock`, `POST /api/blocklist/drivers/:id/blacklist` \| `/unblacklist` — **Security HOD only** |
| Reports | `GET /api/reports/dashboard`, `/vehicles-by-month`, `/vehicles-by-department`, `/approval-status`, `/entry-exit-trend` |
| Audit | `GET /api/audit` (Admin / Security HOD) |

All routes except `/api/auth/login` and `/api/health` require the `Authorization` header.

## 4. Connecting the existing frontend

The `VAPMS.jsx` artifact currently keeps everything in `window.storage` (browser-only,
no real security). To wire it to this backend:

1. Replace the `window.storage.get/set` calls with `fetch()` calls to these endpoints,
   sending the JWT in the `Authorization` header.
2. Replace the client-side login check in `LoginScreen` with a call to
   `POST /api/auth/login`; store the returned token (in memory / a cookie set by your
   own hosting — **not** `localStorage` if you keep using it inside a Claude artifact,
   but a normal browser app deployed outside Claude.ai can use `localStorage` or an
   httpOnly cookie).
3. Swap the pseudo-QR renderer for an `<img src="/api/passes/:id/qr.png">` — it's now a
   real, scannable QR code.
4. This is meaningfully more work than a config change — budget it as its own build.
   If you want, I can generate a version of the frontend wired to this API next.

## 5. Deploying for real

A minimal production setup:

- **Database**: a managed Postgres (Render, Railway, Supabase, RDS, Neon). Run
  `npm run migrate` once against it, then `npm run seed` (or register your real users
  through the Admin UI instead of the demo seed).
- **API**: deploy this folder to Render / Railway / Fly.io / a VPS. Set all the `.env`
  values as real environment variables (never commit `.env`). Put it behind HTTPS —
  most of these platforms do this for you automatically.
- **File uploads**: the default setup writes to local disk (`uploads/`), which is fine
  to start but is lost on redeploy on most platforms. For anything real, swap
  `src/middleware/upload.js` to use `multer-s3` (or GCS/Azure Blob equivalent) pointed
  at a real bucket.
- **Frontend**: host the React app on Vercel/Netlify/Cloudflare Pages, pointed at the
  API's public URL via an environment variable (e.g. `VITE_API_URL`).
- **CORS**: set `CORS_ORIGIN` in `.env` to your deployed frontend's exact URL(s).
- **Secrets**: generate a fresh `JWT_SECRET` for production (e.g. `openssl rand -hex 32`)
  — don't reuse the one from `.env.example`.
- **Backups**: enable automatic daily backups on the managed Postgres instance (this
  satisfies the "Daily Backup" item in the original spec — it's a database setting, not
  application code).

## 6. Security notes

- Passwords are hashed with bcrypt (cost 12) — never stored or logged in plaintext.
- Login responses never include `password_hash`.
- Login endpoint is rate-limited (20 attempts / 15 min per IP) to slow brute forcing.
- `requireAuth` re-checks the user's status in the database on every request, so
  deactivating an account takes effect immediately, not just at next login.
- Block/Blacklist routes use `requireRole("Security HOD")` server-side — this is now
  enforced by the API itself, not just hidden in the UI.
- Rotate `JWT_SECRET` and re-issue tokens if it's ever exposed.
- Add HTTPS (via your hosting platform or a reverse proxy) before handling real data —
  this backend assumes TLS terminates in front of it.
