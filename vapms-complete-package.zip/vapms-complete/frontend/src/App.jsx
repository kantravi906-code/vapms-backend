import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  LayoutDashboard, Car, Users, ShieldCheck, QrCode, Ban, FileBarChart2,
  Settings2, LogOut, Plus, X, Check, RotateCcw, Search, Printer, Download,
  Mail, AlertTriangle, CheckCircle2, XCircle, Clock, Bell, ChevronRight,
  Upload, Trash2, ScanLine, DoorOpen, DoorClosed, ListChecks, Building2, Menu2,
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, LineChart, Line, Legend,
} from "recharts";
import { api, normalizeVehicle, normalizeDriver, normalizeUser, normalizeApprovalLog } from "./lib/api.js";

/* ============================== THEME ============================== */
const T = {
  bg: "#0E1217", panel: "#171C24", panel2: "#1D2430", border: "#2A3340",
  borderSoft: "#232A35", text: "#E8EBF0", textDim: "#8B95A5", textFaint: "#5B6472",
  amber: "#F0A73C", amberDim: "#4A3A1E", green: "#3EB56F", greenDim: "#1C3527",
  red: "#E5555B", redDim: "#3A1F22", blue: "#4C8DFF", blueDim: "#1B2740",
  purple: "#9B7FE8",
};

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap');`;

/* ============================== CONSTANTS ============================== */
const APPROVAL_STAGES = ["Safety", "Plant HOD", "Traffic Marshal", "Security HOD"];
const ROLES = [
  "System Administrator", "Contractor/User", "Safety", "Plant HOD",
  "Traffic Marshal", "Security HOD", "Security Supervisor", "Gate Operator",
];
const ROLE_TABS = {
  "System Administrator": ["dashboard", "vehicles", "drivers", "approvals", "passes", "gate", "blocklist", "reports", "admin"],
  "Contractor/User": ["dashboard", "vehicles", "drivers", "passes"],
  "Safety": ["dashboard", "vehicles", "drivers", "approvals", "reports"],
  "Plant HOD": ["dashboard", "vehicles", "drivers", "approvals", "reports"],
  "Traffic Marshal": ["dashboard", "vehicles", "drivers", "approvals", "reports"],
  "Security HOD": ["dashboard", "vehicles", "drivers", "approvals", "passes", "gate", "blocklist", "reports"],
  "Security Supervisor": ["dashboard", "gate", "vehicles", "reports"],
  "Gate Operator": ["dashboard", "gate"],
};
const TAB_META = {
  dashboard: { label: "Dashboard", icon: LayoutDashboard },
  vehicles: { label: "Vehicles", icon: Car },
  drivers: { label: "Drivers", icon: Users },
  approvals: { label: "Approvals", icon: ShieldCheck },
  passes: { label: "Passes", icon: QrCode },
  gate: { label: "Gate / QR", icon: ScanLine },
  blocklist: { label: "Block / Blacklist", icon: Ban },
  reports: { label: "Reports", icon: FileBarChart2 },
  admin: { label: "Admin", icon: Settings2 },
};

const VEHICLE_DOC_TYPES = ["RC", "Insurance", "PUC", "Fitness Certificate", "Permit", "Safety Checklist", "Service Record", "GPS Certificate"];
const DRIVER_DOC_TYPES = ["Driving Licence", "Medical Certificate", "Gate Pass", "Driver Assessment", "VDSS Training Certificate"];

const VEHICLE_BLOCK_REASONS = ["Document Expired", "Safety Violation", "Unauthorized Entry", "Accident", "Blacklisted Contractor", "Security Concern", "Other"];
const DRIVER_BLOCK_REASONS = ["Safety Violation", "Fake Documents", "Security Misconduct", "Unauthorized Activity", "Licence Expired", "Other"];

/* ============================== UTILS ============================== */
const uid = (p = "ID") => `${p}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
const todayISO = () => new Date().toISOString().slice(0, 10);
const fmtDate = (iso) => { if (!iso) return "—"; const d = new Date(iso + "T00:00:00"); return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }); };
const fmtDateTime = (iso) => { const d = new Date(iso); return d.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }); };
const addDays = (iso, n) => { const d = new Date(iso + "T00:00:00"); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const daysUntil = (iso) => { if (!iso) return null; const d = new Date(iso + "T00:00:00"); const t = new Date(todayISO() + "T00:00:00"); return Math.round((d - t) / 86400000); };
const docStatus = (iso) => { if (!iso) return "Missing"; const du = daysUntil(iso); if (du < 0) return "Expired"; if (du <= 30) return "Expiring Soon"; return "Valid"; };
const cls = (...a) => a.filter(Boolean).join(" ");

function overallDocStatus(docs, types) {
  let worst = "Valid";
  for (const t of types) {
    const s = docStatus(docs?.[t]?.expiryDate);
    if (s === "Expired" || s === "Missing") return "Expired";
    if (s === "Expiring Soon") worst = "Expiring Soon";
  }
  return worst;
}

/* ============================== SMALL UI ATOMS ============================== */
function Badge({ tone = "dim", children, style }) {
  const map = {
    green: { bg: T.greenDim, fg: T.green }, red: { bg: T.redDim, fg: T.red },
    amber: { bg: T.amberDim, fg: T.amber }, blue: { bg: T.blueDim, fg: T.blue },
    dim: { bg: T.panel2, fg: T.textDim },
  };
  const c = map[tone] || map.dim;
  return <span style={{ background: c.bg, color: c.fg, fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, fontWeight: 600, padding: "3px 8px", borderRadius: 5, letterSpacing: 0.3, whiteSpace: "nowrap", ...style }}>{children}</span>;
}
function toneForDocStatus(s) { return s === "Valid" ? "green" : s === "Expiring Soon" ? "amber" : "red"; }
function toneForStatus(s) {
  if (s === "Approved") return "green"; if (s === "Rejected") return "red";
  if (s === "Sent Back") return "amber"; if (s === "Pending") return "blue"; return "dim";
}

function Panel({ title, right, children, style }) {
  return (
    <div style={{ background: T.panel, border: `1px solid ${T.border}`, borderRadius: 10, padding: 16, ...style }}>
      {(title || right) && (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          {title && <h3 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 14, fontWeight: 600, color: T.text, margin: 0, letterSpacing: 0.2 }}>{title}</h3>}
          {right}
        </div>
      )}
      {children}
    </div>
  );
}

function StatCard({ label, value, icon: Icon, tone = "amber", onClick }) {
  const c = { amber: T.amber, green: T.green, red: T.red, blue: T.blue }[tone] || T.amber;
  return (
    <div onClick={onClick} style={{ background: T.panel, border: `1px solid ${T.border}`, borderTop: `3px solid ${c}`, borderRadius: 8, padding: "14px 16px", cursor: onClick ? "pointer" : "default", minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <span style={{ fontFamily: "'Inter'", fontSize: 11.5, color: T.textDim, fontWeight: 500, textTransform: "uppercase", letterSpacing: 0.4 }}>{label}</span>
        <Icon size={15} color={c} />
      </div>
      <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 26, fontWeight: 700, color: T.text }}>{value}</div>
    </div>
  );
}

function Field({ label, children, span }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 5, gridColumn: span ? `span ${span}` : undefined }}>
      <span style={{ fontSize: 11.5, color: T.textDim, fontWeight: 500, fontFamily: "'Inter'" }}>{label}</span>
      {children}
    </label>
  );
}
const inputStyle = { background: T.panel2, border: `1px solid ${T.border}`, borderRadius: 6, padding: "8px 10px", color: T.text, fontFamily: "'Inter'", fontSize: 13, outline: "none", width: "100%", boxSizing: "border-box" };
function TInput(props) { return <input {...props} style={{ ...inputStyle, ...(props.style || {}) }} />; }
function TSelect({ children, ...props }) { return <select {...props} style={{ ...inputStyle, ...(props.style || {}) }}>{children}</select>; }
function TTextArea(props) { return <textarea {...props} style={{ ...inputStyle, minHeight: 60, resize: "vertical", ...(props.style || {}) }} />; }

function Button({ children, tone = "default", icon: Icon, style, ...props }) {
  const map = {
    default: { bg: T.panel2, fg: T.text, bd: T.border },
    primary: { bg: T.amber, fg: "#1A1305", bd: T.amber },
    green: { bg: T.green, fg: "#06210F", bd: T.green },
    red: { bg: T.red, fg: "#2B0C0E", bd: T.red },
    ghost: { bg: "transparent", fg: T.textDim, bd: "transparent" },
  };
  const c = map[tone] || map.default;
  return (
    <button {...props} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: c.bg, color: c.fg, border: `1px solid ${c.bd}`, borderRadius: 6, padding: "8px 13px", fontFamily: "'Inter'", fontWeight: 600, fontSize: 12.5, cursor: "pointer", ...style }}>
      {Icon && <Icon size={14} />} {children}
    </button>
  );
}

function Modal({ title, onClose, children, width = 720 }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(6,8,11,0.72)", display: "flex", alignItems: "flex-start", justifyContent: "center", zIndex: 50, padding: "4vh 16px", overflowY: "auto" }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ background: T.panel, border: `1px solid ${T.border}`, borderRadius: 10, width: "100%", maxWidth: width, padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <h3 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 16, color: T.text, margin: 0 }}>{title}</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", color: T.textDim, cursor: "pointer" }}><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function DataTable({ columns, rows, emptyText = "No records found." }) {
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "'Inter'" }}>
        <thead>
          <tr>{columns.map((c) => <th key={c.key} style={{ textAlign: "left", fontSize: 11, color: T.textFaint, textTransform: "uppercase", letterSpacing: 0.4, padding: "8px 10px", borderBottom: `1px solid ${T.border}`, fontWeight: 600 }}>{c.label}</th>)}</tr>
        </thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={columns.length} style={{ padding: 20, textAlign: "center", color: T.textFaint, fontSize: 13 }}>{emptyText}</td></tr>}
          {rows.map((row, i) => (
            <tr key={row.id || i} style={{ borderBottom: `1px solid ${T.borderSoft}` }}>
              {columns.map((c) => <td key={c.key} style={{ padding: "9px 10px", fontSize: 12.5, color: T.text }}>{c.render ? c.render(row) : row[c.key]}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ============================== DOCUMENT TABLE (registration) ============================== */
function DocumentEditor({ docTypes, docs, onChange }) {
  const set = (type, field, value) => onChange({ ...docs, [type]: { ...(docs[type] || {}), [field]: value } });
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>{["Document", "Doc Number", "Issue Date", "Expiry Date", "File", "Status"].map(h => <th key={h} style={{ textAlign: "left", fontSize: 10.5, color: T.textFaint, textTransform: "uppercase", padding: "6px 8px", borderBottom: `1px solid ${T.border}` }}>{h}</th>)}</tr>
        </thead>
        <tbody>
          {docTypes.map((type) => {
            const d = docs[type] || {};
            const st = docStatus(d.expiryDate);
            return (
              <tr key={type} style={{ borderBottom: `1px solid ${T.borderSoft}` }}>
                <td style={{ padding: "6px 8px", fontSize: 12.5, color: T.text, fontWeight: 500, whiteSpace: "nowrap" }}>{type}</td>
                <td style={{ padding: "6px 8px" }}><TInput value={d.number || ""} onChange={(e) => set(type, "number", e.target.value)} placeholder="Number" style={{ width: 110, fontSize: 12 }} /></td>
                <td style={{ padding: "6px 8px" }}><TInput type="date" value={d.issueDate || ""} onChange={(e) => set(type, "issueDate", e.target.value)} style={{ fontSize: 12 }} /></td>
                <td style={{ padding: "6px 8px" }}><TInput type="date" value={d.expiryDate || ""} onChange={(e) => set(type, "expiryDate", e.target.value)} style={{ fontSize: 12 }} /></td>
                <td style={{ padding: "6px 8px" }}>
                  <label style={{ display: "flex", alignItems: "center", gap: 5, cursor: "pointer", color: T.textDim, fontSize: 11.5 }}>
                    <Upload size={13} />
                    {d.fileName ? d.fileName.slice(0, 14) : "Choose file"}
                    <input type="file" style={{ display: "none" }} onChange={(e) => set(type, "fileName", e.target.files[0]?.name || "")} />
                  </label>
                </td>
                <td style={{ padding: "6px 8px" }}><Badge tone={toneForDocStatus(st)}>{st}</Badge></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/* ============================== APPROVAL STEPPER ============================== */
function ApprovalStepper({ currentStage, status, log }) {
  return (
    <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 0 }}>
      {APPROVAL_STAGES.map((stage, i) => {
        const entry = [...log].reverse().find(l => l.stage === stage);
        let state = "pending";
        if (status === "Rejected" && i === currentStage) state = "rejected";
        else if (status === "Sent Back" && i === currentStage) state = "sentback";
        else if (i < currentStage || (status === "Approved")) state = "done";
        else if (i === currentStage) state = "active";
        const color = state === "done" ? T.green : state === "active" ? T.amber : state === "rejected" ? T.red : state === "sentback" ? T.amber : T.textFaint;
        return (
          <React.Fragment key={stage}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, minWidth: 90 }}>
              <div style={{ width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: state === "done" ? T.greenDim : state === "pending" ? T.panel2 : T.amberDim, border: `2px solid ${color}` }}>
                {state === "done" ? <Check size={13} color={color} /> : state === "rejected" ? <X size={13} color={color} /> : <span style={{ fontSize: 11, color, fontWeight: 700 }}>{i + 1}</span>}
              </div>
              <span style={{ fontSize: 10.5, color: T.textDim, textAlign: "center", fontFamily: "'Inter'" }}>{stage}</span>
              {entry && <span style={{ fontSize: 9.5, color: T.textFaint }}>{fmtDate(entry.date)}</span>}
            </div>
            {i < APPROVAL_STAGES.length - 1 && <div style={{ flex: 1, height: 2, background: i < currentStage ? T.green : T.border, minWidth: 20, marginBottom: 18 }} />}
          </React.Fragment>
        );
      })}
    </div>
  );
}

/* ============================== PASS CARD ============================== */
function PassCard({ vehicle, driver }) {
  const expired = vehicle.passValidTill && daysUntil(vehicle.passValidTill) < 0;
  const status = vehicle.blocked ? "BLOCKED" : expired ? "EXPIRED" : "ACTIVE";
  const strip = status === "ACTIVE" ? T.green : status === "EXPIRED" ? T.textFaint : T.red;
  return (
    <div style={{ width: 340, borderRadius: 14, overflow: "hidden", background: "linear-gradient(160deg,#1D2430,#141920)", border: `1px solid ${T.border}`, boxShadow: "0 8px 24px rgba(0,0,0,0.35)" }}>
      <div style={{ background: strip, padding: "8px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 12, color: "#0E1217" }}>VEHICLE ACCESS PASS</span>
        <span style={{ fontFamily: "'IBM Plex Mono'", fontWeight: 700, fontSize: 11, color: "#0E1217" }}>{status}</span>
      </div>
      <div style={{ padding: 16, display: "flex", gap: 14 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "'IBM Plex Mono'", fontSize: 10, color: T.textFaint, marginBottom: 2 }}>{vehicle.passNumber || "—"}</div>
          <div style={{ fontFamily: "'Space Grotesk'", fontSize: 20, fontWeight: 700, color: T.text, letterSpacing: 1 }}>{vehicle.vehicleNumber}</div>
          <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2 }}>{vehicle.vehicleType} · {vehicle.department}</div>
          <div style={{ marginTop: 10, display: "grid", gridTemplateColumns: "auto 1fr", rowGap: 3, columnGap: 8, fontSize: 11 }}>
            <span style={{ color: T.textFaint }}>Driver</span><span style={{ color: T.text }}>{driver?.name || "Not assigned"}</span>
            <span style={{ color: T.textFaint }}>Contractor</span><span style={{ color: T.text }}>{vehicle.contractor}</span>
            <span style={{ color: T.textFaint }}>Company</span><span style={{ color: T.text }}>{vehicle.company}</span>
            <span style={{ color: T.textFaint }}>Valid till</span><span style={{ color: T.text }}>{fmtDate(vehicle.passValidTill)}</span>
            <span style={{ color: T.textFaint }}>Emergency</span><span style={{ color: T.text }}>{driver?.emergencyContact || "—"}</span>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
          {vehicle.passNumber
            ? <img src={api.qrUrl(vehicle.id)} alt="Scannable pass QR code" width={92} height={92} style={{ background: "#fff", borderRadius: 6 }} />
            : <div style={{ width: 92, height: 92, background: T.panel2, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: T.textFaint, textAlign: "center" }}>No pass yet</div>}
          <span style={{ fontSize: 8.5, color: T.textFaint, fontFamily: "'IBM Plex Mono'" }}>SCAN AT GATE</span>
        </div>
      </div>
    </div>
  );
}

/* ============================== APP ============================== */
export default function App() {
  const [authChecked, setAuthChecked] = useState(false);
  const [currentUser, setCurrentUser] = useState(null); // { id, name, empId, username, role, ... }
  const role = currentUser?.role || null;
  const userName = currentUser?.name || "";
  const [tab, setTab] = useState("dashboard");
  const [navOpen, setNavOpen] = useState(false);
  const [toast, setToast] = useState(null);

  // Resume a session from a previously-stored token, if the token is still valid.
  useEffect(() => {
    (async () => {
      const cached = api.getStoredUser();
      if (api.isAuthed() && cached) setCurrentUser(cached);
      setAuthChecked(true);
    })();
  }, []);

  const notify = (msg, tone = "green") => { setToast({ msg, tone }); setTimeout(() => setToast(null), 2800); };

  // Every page calls this on an API error - shows a red toast, and signs the user out
  // if the server says the session is no longer valid.
  const handleApiError = (err) => {
    notify(err.message || "Something went wrong.", "red");
    if (/expired|invalid.*token|missing bearer/i.test(err.message || "")) {
      api.logout(); setCurrentUser(null);
    }
  };

  if (!authChecked) return <div style={{ background: T.bg, height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: T.textDim, fontFamily: "'Inter'" }}>Loading VAPMS…</div>;

  if (!role) return <LoginScreen onLogin={(user) => { setCurrentUser(user); setTab("dashboard"); }} />;

  const tabs = ROLE_TABS[role] || ["dashboard"];

  return (
    <div className="vapms-shell" style={{ background: T.bg, minHeight: "100vh", color: T.text, fontFamily: "'Inter', sans-serif", display: "flex" }}>
      <style>{`
        ${FONT_IMPORT}
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        ::selection { background: ${T.amber}55; }
        input[type=date]::-webkit-calendar-picker-indicator{filter:invert(0.7);}
        html, body { overscroll-behavior-y: contain; }
        .vapms-topbar { display: none; }
        .vapms-scrim { display: none; }
        @media (max-width: 860px) {
          .vapms-sidebar {
            position: fixed; z-index: 60; left: 0; top: 0; height: 100dvh;
            transform: translateX(-100%); transition: transform 0.2s ease;
            box-shadow: 4px 0 24px rgba(0,0,0,0.4);
          }
          .vapms-sidebar.open { transform: translateX(0); }
          .vapms-topbar { display: flex; }
          .vapms-scrim.open { display: block; }
          .vapms-main { padding: 14px !important; padding-top: 70px !important; }
          .grid-2, .grid-3 { grid-template-columns: 1fr !important; }
        }
      `}</style>

      {/* MOBILE TOP BAR */}
      <div className="vapms-topbar" style={{ position: "fixed", top: 0, left: 0, right: 0, height: 54, background: T.panel, borderBottom: `1px solid ${T.border}`, alignItems: "center", gap: 10, padding: "0 12px", zIndex: 50 }}>
        <button onClick={() => setNavOpen(true)} aria-label="Open menu" style={{ background: "none", border: "none", color: T.text, cursor: "pointer", padding: 6 }}><Menu2 size={20} /></button>
        <div style={{ width: 26, height: 26, borderRadius: 6, background: T.amber, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><ShieldCheck size={14} color="#1A1305" /></div>
        <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 14 }}>VAPMS</div>
        <div style={{ marginLeft: "auto", fontSize: 10.5, color: T.textDim, textAlign: "right" }}>{TAB_META[tab]?.label}</div>
      </div>

      {/* SCRIM (mobile drawer backdrop) */}
      <div className={cls("vapms-scrim", navOpen && "open")} onClick={() => setNavOpen(false)} style={{ position: "fixed", inset: 0, background: "rgba(6,8,11,0.6)", zIndex: 55 }} />

      {/* SIDEBAR / DRAWER */}
      <div className={cls("vapms-sidebar", navOpen && "open")} style={{ width: 208, background: T.panel, borderRight: `1px solid ${T.border}`, display: "flex", flexDirection: "column", flexShrink: 0, position: "sticky", top: 0, height: "100vh" }}>
        <div style={{ padding: "18px 16px", borderBottom: `1px solid ${T.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 30, height: 30, borderRadius: 7, background: T.amber, display: "flex", alignItems: "center", justifyContent: "center" }}><ShieldCheck size={16} color="#1A1305" /></div>
            <div>
              <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 14, lineHeight: 1 }}>VAPMS</div>
              <div style={{ fontSize: 9, color: T.textFaint, letterSpacing: 0.5 }}>ACCESS CONTROL</div>
            </div>
          </div>
          <button className="vapms-topbar" onClick={() => setNavOpen(false)} aria-label="Close menu" style={{ display: navOpen ? "flex" : "none", background: "none", border: "none", color: T.textDim, cursor: "pointer" }}><X size={18} /></button>
        </div>
        <div style={{ flex: 1, padding: "10px 8px", overflowY: "auto" }}>
          {tabs.map((tKey) => {
            const meta = TAB_META[tKey]; const Icon = meta.icon; const active = tab === tKey;
            return (
              <button key={tKey} onClick={() => { setTab(tKey); setNavOpen(false); }} style={{ width: "100%", display: "flex", alignItems: "center", gap: 9, padding: "11px 10px", marginBottom: 2, background: active ? T.amberDim : "transparent", color: active ? T.amber : T.textDim, border: "none", borderRadius: 7, cursor: "pointer", fontFamily: "'Inter'", fontSize: 13, fontWeight: 500, textAlign: "left" }}>
                <Icon size={16} /> {meta.label}
              </button>
            );
          })}
        </div>
        <div style={{ padding: 12, borderTop: `1px solid ${T.border}` }}>
          <div style={{ fontSize: 11, color: T.text, fontWeight: 600 }}>{userName}{currentUser?.empId ? ` · ${currentUser.empId}` : ""}</div>
          <div style={{ fontSize: 10, color: T.textFaint, marginBottom: 8 }}>{role}<span style={{ color: T.green }}> · verified</span></div>
          <Button tone="ghost" icon={LogOut} onClick={() => { api.logout(); setCurrentUser(null); }} style={{ padding: "6px 8px", fontSize: 11.5 }}>Sign out</Button>
        </div>
      </div>

      {/* MAIN */}
      <div className="vapms-main" style={{ flex: 1, minWidth: 0, padding: 22 }}>
        {tab === "dashboard" && <Dashboard role={role} onError={handleApiError} />}
        {tab === "vehicles" && <VehiclesPage role={role} currentUser={currentUser} notify={notify} onError={handleApiError} />}
        {tab === "drivers" && <DriversPage role={role} currentUser={currentUser} notify={notify} onError={handleApiError} />}
        {tab === "approvals" && <ApprovalsPage role={role} notify={notify} onError={handleApiError} />}
        {tab === "passes" && <PassesPage role={role} notify={notify} onError={handleApiError} />}
        {tab === "gate" && <GatePage role={role} notify={notify} onError={handleApiError} />}
        {tab === "blocklist" && <BlocklistPage currentUser={currentUser} notify={notify} onError={handleApiError} />}
        {tab === "reports" && <ReportsPage onError={handleApiError} />}
        {tab === "admin" && <AdminPage role={role} notify={notify} onError={handleApiError} />}
      </div>

      {toast && (
        <div style={{ position: "fixed", bottom: 22, right: 22, background: toast.tone === "red" ? T.redDim : T.greenDim, border: `1px solid ${toast.tone === "red" ? T.red : T.green}`, color: toast.tone === "red" ? T.red : T.green, padding: "10px 16px", borderRadius: 8, fontSize: 12.5, fontFamily: "'Inter'", fontWeight: 500, zIndex: 100, display: "flex", alignItems: "center", gap: 8 }}>
          {toast.tone === "red" ? <XCircle size={15} /> : <CheckCircle2 size={15} />} {toast.msg}
        </div>
      )}
    </div>
  );
}


/* ============================== LOGIN ============================== */
function LoginScreen({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showDemo, setShowDemo] = useState(false);

  const DEMO_ACCOUNTS = [
    ["System Administrator", "deepak.mehta", "admin123"],
    ["Contractor/User", "ramesh.kumar", "contractor123"],
    ["Safety", "priya.nair", "safety123"],
    ["Plant HOD", "anita.sharma", "plant123"],
    ["Traffic Marshal", "harpreet.singh", "traffic123"],
    ["Security HOD", "vikram.rao", "security123"],
    ["Security Supervisor", "salim.khan", "super123"],
    ["Gate Operator", "rakesh.yadav", "gate123"],
  ];

  const submit = async () => {
    setError("");
    if (!username.trim() || !password) { setError("Enter both username and password."); return; }
    setLoading(true);
    try {
      const user = await api.login(username.trim(), password);
      onLogin(user);
    } catch (err) {
      setError(err.message || "Sign in failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ background: `radial-gradient(circle at 20% 20%, #1a212b 0%, ${T.bg} 60%)`, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter'", padding: 16 }}>
      <style>{`${FONT_IMPORT}`}</style>
      <div style={{ width: 380, maxWidth: "100%", background: T.panel, border: `1px solid ${T.border}`, borderRadius: 12, padding: 28 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
          <div style={{ width: 38, height: 38, borderRadius: 9, background: T.amber, display: "flex", alignItems: "center", justifyContent: "center" }}><ShieldCheck size={20} color="#1A1305" /></div>
          <div>
            <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 18, color: T.text }}>VAPMS</div>
            <div style={{ fontSize: 10.5, color: T.textFaint, letterSpacing: 0.5 }}>VEHICLE ACCESS PASS MANAGEMENT</div>
          </div>
        </div>
        <p style={{ fontSize: 12, color: T.textDim, marginBottom: 20, lineHeight: 1.5 }}>Sign in with your registered username and password. Data is shared live across every device connected to this system.</p>

        <Field label="Username"><TInput value={username} onChange={(e) => setUsername(e.target.value)} placeholder="e.g. vikram.rao" onKeyDown={(e) => e.key === "Enter" && submit()} /></Field>
        <div style={{ height: 12 }} />
        <Field label="Password"><TInput type="password" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="••••••••" /></Field>
        {error && <div style={{ color: T.red, fontSize: 11.5, marginTop: 8 }}>{error}</div>}

        <div style={{ height: 18 }} />
        <Button tone="primary" style={{ width: "100%", justifyContent: "center", padding: "10px 0", opacity: loading ? 0.6 : 1 }} onClick={submit} disabled={loading}>{loading ? "Signing in…" : "Sign in"} <ChevronRight size={14} /></Button>

        <button onClick={() => setShowDemo(!showDemo)} style={{ background: "none", border: "none", color: T.textFaint, fontSize: 10.5, marginTop: 14, cursor: "pointer", textDecoration: "underline" }}>{showDemo ? "Hide" : "Show"} demo accounts</button>
        {showDemo && (
          <div style={{ marginTop: 8, fontSize: 10.5, color: T.textDim, background: T.panel2, borderRadius: 6, padding: "8px 10px", display: "flex", flexDirection: "column", gap: 4, fontFamily: "'IBM Plex Mono'" }}>
            {DEMO_ACCOUNTS.map(([r, u, p]) => <div key={u} style={{ display: "flex", justifyContent: "space-between", gap: 10 }}><span>{r}</span><span>{u} / {p}</span></div>)}
            <div style={{ color: T.textFaint, marginTop: 4 }}>Only works if the backend was seeded with <code>npm run seed</code>.</div>
          </div>
        )}
      </div>
    </div>
  );
}


/* ============================== DASHBOARD ============================== */
function Dashboard({ role, onError }) {
  const [stats, setStats] = useState(null);
  const [monthWise, setMonthWise] = useState([]);
  const [deptWise, setDeptWise] = useState([]);
  const [approvalStatus, setApprovalStatus] = useState([]);
  const [entryExitTrend, setEntryExitTrend] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const [dash, month, dept, appr, trend] = await Promise.all([
          api.getDashboard(), api.getVehiclesByMonth(), api.getVehiclesByDepartment(), api.getApprovalStatus(), api.getEntryExitTrend(),
        ]);
        setStats(dash);
        setMonthWise(month.data.map(r => ({ month: r.month, vehicles: r.vehicles })));
        setDeptWise(dept.data.map(r => ({ department: r.department || "Unassigned", count: r.count })));
        setApprovalStatus(appr.data);
        setEntryExitTrend(trend.data);
      } catch (err) { onError(err); }
      setLoading(false);
    })();
  }, []);

  const pieColors = [T.green, T.blue, T.amber, T.red, T.purple];

  if (loading || !stats) return <div style={{ color: T.textFaint, fontSize: 13, padding: 30 }}>Loading dashboard…</div>;

  return (
    <div>
      <div style={{ marginBottom: 18 }}>
        <h1 style={{ fontFamily: "'Space Grotesk'", fontSize: 21, margin: 0, color: T.text }}>Dashboard</h1>
        <p style={{ fontSize: 12.5, color: T.textDim, margin: "3px 0 0" }}>Live overview · {fmtDate(todayISO())} · signed in as {role}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 12, marginBottom: 14 }}>
        <StatCard label="Registered Vehicles" value={stats.totalVehicles} icon={Car} tone="amber" />
        <StatCard label="Active Passes" value={stats.activePasses} icon={QrCode} tone="green" />
        <StatCard label="Pending Approvals" value={stats.pendingApprovals} icon={Clock} tone="blue" />
        <StatCard label="Expired Documents" value={stats.expiredDocuments} icon={AlertTriangle} tone="red" />
        <StatCard label="Registered Drivers" value={stats.registeredDrivers} icon={Users} tone="amber" />
        <StatCard label="Blocked Vehicles" value={stats.blockedVehicles} icon={Ban} tone="red" />
        <StatCard label="Blocked Drivers" value={stats.blockedDrivers} icon={Ban} tone="red" />
        <StatCard label="QR Scans Today" value={stats.qrScansToday} icon={ScanLine} tone="blue" />
        <StatCard label="Today's Entries" value={stats.todayEntries} icon={DoorOpen} tone="green" />
        <StatCard label="Today's Exits" value={stats.todayExits} icon={DoorClosed} tone="amber" />
        <StatCard label="Expiring ≤ 15 Days" value={stats.expiring15} icon={Bell} tone="amber" />
        <StatCard label="Expiring ≤ 30 Days" value={stats.expiring30} icon={Bell} tone="amber" />
      </div>

      <div className="grid-2" style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 12, marginBottom: 12 }}>
        <Panel title="Vehicle Registration (Month-wise)">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthWise}>
              <CartesianGrid stroke={T.borderSoft} vertical={false} />
              <XAxis dataKey="month" tick={{ fill: T.textFaint, fontSize: 11 }} axisLine={{ stroke: T.border }} tickLine={false} />
              <YAxis tick={{ fill: T.textFaint, fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ background: T.panel2, border: `1px solid ${T.border}`, borderRadius: 6, fontSize: 12 }} />
              <Bar dataKey="vehicles" fill={T.amber} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Approval Status">
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={approvalStatus} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
                {approvalStatus.map((e, i) => <Cell key={i} fill={pieColors[i % pieColors.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: T.panel2, border: `1px solid ${T.border}`, borderRadius: 6, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11, color: T.textDim }} />
            </PieChart>
          </ResponsiveContainer>
        </Panel>
      </div>

      <div className="grid-2" style={{ display: "grid", gridTemplateColumns: "1fr 1.3fr", gap: 12 }}>
        <Panel title="Department-wise Vehicles">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={deptWise} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid stroke={T.borderSoft} horizontal={false} />
              <XAxis type="number" tick={{ fill: T.textFaint, fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
              <YAxis type="category" dataKey="department" tick={{ fill: T.textDim, fontSize: 11 }} axisLine={false} tickLine={false} width={80} />
              <Tooltip contentStyle={{ background: T.panel2, border: `1px solid ${T.border}`, borderRadius: 6, fontSize: 12 }} />
              <Bar dataKey="count" fill={T.blue} radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Entry vs Exit Trend (7 days)">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={entryExitTrend}>
              <CartesianGrid stroke={T.borderSoft} vertical={false} />
              <XAxis dataKey="day" tick={{ fill: T.textFaint, fontSize: 11 }} axisLine={{ stroke: T.border }} tickLine={false} />
              <YAxis tick={{ fill: T.textFaint, fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ background: T.panel2, border: `1px solid ${T.border}`, borderRadius: 6, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11, color: T.textDim }} />
              <Line type="monotone" dataKey="entries" stroke={T.green} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="exits" stroke={T.red} strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Panel>
      </div>
    </div>
  );
}


/* ============================== VEHICLES PAGE ============================== */
function emptyVehicle() {
  return { vehicleNumber: "", vehicleType: "", company: "", contractor: "", ownerName: "", department: "", purpose: "", gpsInstalled: false, photoName: "", documents: {}, assignedDriverId: null };
}

function VehiclesPage({ role, currentUser, notify, onError }) {
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [masters, setMasters] = useState({ departments: [], contractors: [], companies: [], vehicleTypes: [] });
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyVehicle());
  const [selected, setSelected] = useState(null);
  const [selectedDetail, setSelectedDetail] = useState(null);
  const [saving, setSaving] = useState(false);

  const refresh = async () => {
    setLoading(true);
    try {
      const [v, d, m] = await Promise.all([api.getVehicles(), api.getDrivers(), api.getMasters()]);
      setVehicles(v.vehicles.map(normalizeVehicle));
      setDrivers(d.drivers.map(normalizeDriver));
      setMasters(m);
    } catch (err) { onError(err); }
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const save = async () => {
    if (!form.vehicleNumber || !form.vehicleType) { notify("Vehicle number and type are required", "red"); return; }
    setSaving(true);
    try {
      await api.registerVehicle(form);
      notify(`Vehicle ${form.vehicleNumber} registered and sent for Safety approval.`);
      setShowForm(false); setForm(emptyVehicle());
      refresh();
    } catch (err) { onError(err); }
    setSaving(false);
  };

  const openDetail = async (v) => {
    setSelected(v); setSelectedDetail(null);
    try {
      const { vehicle, approvalLog } = await api.getVehicle(v.id);
      setSelectedDetail({ vehicle: normalizeVehicle(vehicle), approvalLog: normalizeApprovalLog(approvalLog) });
    } catch (err) { onError(err); }
  };

  return (
    <div>
      <PageHeader title="Vehicles" subtitle="Register vehicles and track their document & approval status." action={
        (role === "Contractor/User" || role === "System Administrator") && <Button tone="primary" icon={Plus} onClick={() => { setForm(emptyVehicle()); setShowForm(true); }}>Register Vehicle</Button>
      } />

      <Panel>
        {loading ? <p style={{ color: T.textFaint, fontSize: 13, padding: 10 }}>Loading…</p> : (
          <DataTable
            columns={[
              { key: "vehicleNumber", label: "Vehicle No.", render: r => <span style={{ fontFamily: "'IBM Plex Mono'", fontWeight: 600 }}>{r.vehicleNumber}</span> },
              { key: "vehicleType", label: "Type" },
              { key: "department", label: "Department" },
              { key: "contractor", label: "Contractor" },
              { key: "status", label: "Approval", render: r => <Badge tone={toneForStatus(r.status)}>{r.status}</Badge> },
              { key: "docs", label: "Documents", render: r => { const s = overallDocStatus(r.documents, VEHICLE_DOC_TYPES); return <Badge tone={toneForDocStatus(s)}>{s}</Badge>; } },
              { key: "blocked", label: "Block", render: r => r.blocked ? <Badge tone="red">Blocked</Badge> : <Badge tone="green">Active</Badge> },
              { key: "actions", label: "", render: r => <Button tone="ghost" onClick={() => openDetail(r)} style={{ padding: "4px 8px" }}>View <ChevronRight size={13} /></Button> },
            ]}
            rows={vehicles}
          />
        )}
      </Panel>

      {showForm && (
        <Modal title="Register Vehicle" onClose={() => setShowForm(false)} width={860}>
          <div className="grid-3" style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <Field label="Vehicle Number *"><TInput value={form.vehicleNumber} onChange={e => setForm({ ...form, vehicleNumber: e.target.value.toUpperCase() })} placeholder="PB-10-AB-1234" /></Field>
            <Field label="Vehicle Type *">
              <TSelect value={form.vehicleType} onChange={e => setForm({ ...form, vehicleType: e.target.value })}>
                <option value="">Select</option>{masters.vehicleTypes.map(v => <option key={v}>{v}</option>)}
              </TSelect>
            </Field>
            <Field label="Department">
              <TSelect value={form.department} onChange={e => setForm({ ...form, department: e.target.value })}>
                <option value="">Select</option>{masters.departments.map(v => <option key={v}>{v}</option>)}
              </TSelect>
            </Field>
            <Field label="Company">
              <TSelect value={form.company} onChange={e => setForm({ ...form, company: e.target.value })}>
                <option value="">Select</option>{masters.companies.map(v => <option key={v}>{v}</option>)}
              </TSelect>
            </Field>
            <Field label="Contractor Name">
              <TSelect value={form.contractor} onChange={e => setForm({ ...form, contractor: e.target.value })}>
                <option value="">Select</option>{masters.contractors.map(v => <option key={v}>{v}</option>)}
              </TSelect>
            </Field>
            <Field label="Owner Name"><TInput value={form.ownerName} onChange={e => setForm({ ...form, ownerName: e.target.value })} /></Field>
            <Field label="Purpose" span={2}><TInput value={form.purpose} onChange={e => setForm({ ...form, purpose: e.target.value })} placeholder="e.g. Material Transport" /></Field>
            <Field label="Assign Driver">
              <TSelect value={form.assignedDriverId || ""} onChange={e => setForm({ ...form, assignedDriverId: e.target.value || null })}>
                <option value="">None</option>{drivers.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
              </TSelect>
            </Field>
            <Field label="GPS Installed">
              <TSelect value={form.gpsInstalled ? "yes" : "no"} onChange={e => setForm({ ...form, gpsInstalled: e.target.value === "yes" })}>
                <option value="no">No</option><option value="yes">Yes</option>
              </TSelect>
            </Field>
            <Field label="Vehicle Photograph">
              <label style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", ...inputStyle }}>
                <Upload size={13} />{form.photoName || "Choose file"}
                <input type="file" style={{ display: "none" }} onChange={e => setForm({ ...form, photoName: e.target.files[0]?.name || "" })} />
              </label>
            </Field>
          </div>
          <div style={{ marginTop: 18, marginBottom: 8, fontSize: 12.5, fontWeight: 600, color: T.text }}>Mandatory Documents</div>
          <DocumentEditor docTypes={VEHICLE_DOC_TYPES} docs={form.documents} onChange={(d) => setForm({ ...form, documents: d })} />
          <p style={{ fontSize: 11, color: T.textFaint, marginTop: 8 }}>File uploads attach after the vehicle is registered — record document numbers and dates now.</p>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 18 }}>
            <Button onClick={() => setShowForm(false)}>Cancel</Button>
            <Button tone="primary" onClick={save} disabled={saving} style={saving ? { opacity: 0.6 } : {}}>{saving ? "Submitting…" : "Submit for Approval"}</Button>
          </div>
        </Modal>
      )}

      {selected && (
        <Modal title={`Vehicle · ${selected.vehicleNumber}`} onClose={() => setSelected(null)} width={780}>
          {!selectedDetail ? <p style={{ color: T.textFaint, fontSize: 13 }}>Loading…</p> : <VehicleDetail vehicle={selectedDetail.vehicle} approvalLog={selectedDetail.approvalLog} drivers={drivers} />}
        </Modal>
      )}
    </div>
  );
}

function VehicleDetail({ vehicle, approvalLog, drivers }) {
  const driver = drivers.find(d => d.id === vehicle.assignedDriverId);
  return (
    <div>
      <div className="grid-3" style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: 16, fontSize: 12.5 }}>
        <InfoRow label="Type" value={vehicle.vehicleType} /><InfoRow label="Department" value={vehicle.department} /><InfoRow label="Contractor" value={vehicle.contractor} />
        <InfoRow label="Company" value={vehicle.company} /><InfoRow label="Owner" value={vehicle.ownerName} /><InfoRow label="Driver" value={driver?.name || vehicle.driverName || "Not assigned"} />
        <InfoRow label="Purpose" value={vehicle.purpose} /><InfoRow label="GPS" value={vehicle.gpsInstalled ? "Installed" : "Not installed"} /><InfoRow label="Blocked" value={vehicle.blocked ? `Yes (${vehicle.blockInfo?.reason})` : "No"} />
      </div>
      <Panel title="Approval Progress" style={{ marginBottom: 14 }}><ApprovalStepper currentStage={vehicle.currentStage} status={vehicle.status} log={approvalLog} /></Panel>
      <Panel title="Documents"><DocumentEditor docTypes={VEHICLE_DOC_TYPES} docs={vehicle.documents} onChange={() => {}} /></Panel>
      {approvalLog?.length > 0 && (
        <Panel title="Approval Remarks" style={{ marginTop: 14 }}>
          {approvalLog.map((l, i) => (
            <div key={i} style={{ fontSize: 12, color: T.textDim, padding: "6px 0", borderBottom: i < approvalLog.length - 1 ? `1px solid ${T.borderSoft}` : "none" }}>
              <b style={{ color: T.text }}>{l.stage}</b> — {l.action} by {l.by} on {fmtDate(l.date)}{l.remarks ? `: "${l.remarks}"` : ""}
            </div>
          ))}
        </Panel>
      )}
    </div>
  );
}

function InfoRow({ label, value }) { return <div><div style={{ color: T.textFaint, fontSize: 10.5, textTransform: "uppercase" }}>{label}</div><div style={{ color: T.text }}>{value || "—"}</div></div>; }

function PageHeader({ title, subtitle, action }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16 }}>
      <div><h1 style={{ fontFamily: "'Space Grotesk'", fontSize: 21, margin: 0, color: T.text }}>{title}</h1><p style={{ fontSize: 12.5, color: T.textDim, margin: "3px 0 0" }}>{subtitle}</p></div>
      {action}
    </div>
  );
}

/* ============================== DRIVERS PAGE ============================== */
function emptyDriver() {
  return { name: "", fatherName: "", mobile: "", aadhaar: "", bloodGroup: "", contractor: "", company: "", address: "", emergencyContact: "", photoName: "", documents: {} };
}

function DriversPage({ role, currentUser, notify, onError }) {
  const [drivers, setDrivers] = useState([]);
  const [masters, setMasters] = useState({ departments: [], contractors: [], companies: [], vehicleTypes: [] });
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyDriver());
  const [selected, setSelected] = useState(null);
  const [selectedDetail, setSelectedDetail] = useState(null);
  const [saving, setSaving] = useState(false);

  const refresh = async () => {
    setLoading(true);
    try {
      const [d, m] = await Promise.all([api.getDrivers(), api.getMasters()]);
      setDrivers(d.drivers.map(normalizeDriver));
      setMasters(m);
    } catch (err) { onError(err); }
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const save = async () => {
    if (!form.name || !form.mobile) { notify("Name and mobile number are required", "red"); return; }
    setSaving(true);
    try {
      await api.registerDriver(form);
      notify(`Driver ${form.name} registered and sent for Safety approval.`);
      setShowForm(false); setForm(emptyDriver());
      refresh();
    } catch (err) { onError(err); }
    setSaving(false);
  };

  const openDetail = async (d) => {
    setSelected(d); setSelectedDetail(null);
    try {
      const { driver, approvalLog } = await api.getDriver(d.id);
      setSelectedDetail({ driver: normalizeDriver(driver), approvalLog: normalizeApprovalLog(approvalLog) });
    } catch (err) { onError(err); }
  };

  return (
    <div>
      <PageHeader title="Drivers" subtitle="Register drivers and track licence & training documents." action={
        (role === "Contractor/User" || role === "System Administrator") && <Button tone="primary" icon={Plus} onClick={() => { setForm(emptyDriver()); setShowForm(true); }}>Register Driver</Button>
      } />
      <Panel>
        {loading ? <p style={{ color: T.textFaint, fontSize: 13, padding: 10 }}>Loading…</p> : (
          <DataTable
            columns={[
              { key: "name", label: "Name" },
              { key: "mobile", label: "Mobile" },
              { key: "contractor", label: "Contractor" },
              { key: "status", label: "Approval", render: r => <Badge tone={toneForStatus(r.status)}>{r.status}</Badge> },
              { key: "docs", label: "Documents", render: r => { const s = overallDocStatus(r.documents, DRIVER_DOC_TYPES); return <Badge tone={toneForDocStatus(s)}>{s}</Badge>; } },
              { key: "blacklisted", label: "Blacklist", render: r => r.blacklisted ? <Badge tone="red">Blacklisted</Badge> : <Badge tone="green">Clear</Badge> },
              { key: "actions", label: "", render: r => <Button tone="ghost" onClick={() => openDetail(r)} style={{ padding: "4px 8px" }}>View <ChevronRight size={13} /></Button> },
            ]}
            rows={drivers}
          />
        )}
      </Panel>

      {showForm && (
        <Modal title="Register Driver" onClose={() => setShowForm(false)} width={860}>
          <div className="grid-3" style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <Field label="Driver Name *"><TInput value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Father's Name"><TInput value={form.fatherName} onChange={e => setForm({ ...form, fatherName: e.target.value })} /></Field>
            <Field label="Mobile Number *"><TInput value={form.mobile} onChange={e => setForm({ ...form, mobile: e.target.value })} /></Field>
            <Field label="Aadhaar Number"><TInput value={form.aadhaar} onChange={e => setForm({ ...form, aadhaar: e.target.value })} placeholder="XXXX-XXXX-XXXX" /></Field>
            <Field label="Blood Group"><TInput value={form.bloodGroup} onChange={e => setForm({ ...form, bloodGroup: e.target.value })} placeholder="e.g. B+" /></Field>
            <Field label="Emergency Contact"><TInput value={form.emergencyContact} onChange={e => setForm({ ...form, emergencyContact: e.target.value })} /></Field>
            <Field label="Contractor">
              <TSelect value={form.contractor} onChange={e => setForm({ ...form, contractor: e.target.value })}><option value="">Select</option>{masters.contractors.map(v => <option key={v}>{v}</option>)}</TSelect>
            </Field>
            <Field label="Company">
              <TSelect value={form.company} onChange={e => setForm({ ...form, company: e.target.value })}><option value="">Select</option>{masters.companies.map(v => <option key={v}>{v}</option>)}</TSelect>
            </Field>
            <Field label="Driver Photograph">
              <label style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", ...inputStyle }}>
                <Upload size={13} />{form.photoName || "Choose file"}
                <input type="file" style={{ display: "none" }} onChange={e => setForm({ ...form, photoName: e.target.files[0]?.name || "" })} />
              </label>
            </Field>
            <Field label="Address" span={3}><TTextArea value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></Field>
          </div>
          <div style={{ marginTop: 18, marginBottom: 8, fontSize: 12.5, fontWeight: 600, color: T.text }}>Mandatory Documents</div>
          <DocumentEditor docTypes={DRIVER_DOC_TYPES} docs={form.documents} onChange={(d) => setForm({ ...form, documents: d })} />
          <p style={{ fontSize: 11, color: T.textFaint, marginTop: 8 }}>File uploads attach after the driver is registered — record document numbers and dates now.</p>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 18 }}>
            <Button onClick={() => setShowForm(false)}>Cancel</Button>
            <Button tone="primary" onClick={save} disabled={saving} style={saving ? { opacity: 0.6 } : {}}>{saving ? "Submitting…" : "Submit for Approval"}</Button>
          </div>
        </Modal>
      )}

      {selected && (
        <Modal title={`Driver · ${selected.name}`} onClose={() => setSelected(null)} width={780}>
          {!selectedDetail ? <p style={{ color: T.textFaint, fontSize: 13 }}>Loading…</p> : (
            <div>
              <div className="grid-3" style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: 16, fontSize: 12.5 }}>
                <InfoRow label="Father's Name" value={selectedDetail.driver.fatherName} /><InfoRow label="Mobile" value={selectedDetail.driver.mobile} /><InfoRow label="Aadhaar" value={selectedDetail.driver.aadhaar} />
                <InfoRow label="Blood Group" value={selectedDetail.driver.bloodGroup} /><InfoRow label="Contractor" value={selectedDetail.driver.contractor} /><InfoRow label="Company" value={selectedDetail.driver.company} />
                <InfoRow label="Emergency Contact" value={selectedDetail.driver.emergencyContact} /><InfoRow label="Blacklisted" value={selectedDetail.driver.blacklisted ? `Yes (${selectedDetail.driver.blacklistInfo?.reason})` : "No"} /><InfoRow label="Address" value={selectedDetail.driver.address} />
              </div>
              <Panel title="Approval Progress" style={{ marginBottom: 14 }}><ApprovalStepper currentStage={selectedDetail.driver.currentStage} status={selectedDetail.driver.status} log={selectedDetail.approvalLog} /></Panel>
              <Panel title="Documents"><DocumentEditor docTypes={DRIVER_DOC_TYPES} docs={selectedDetail.driver.documents} onChange={() => {}} /></Panel>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}

function ApprovalsPage({ role, notify, onError }) {
  const [kind, setKind] = useState("vehicles");
  const [queue, setQueue] = useState([]);
  const [counts, setCounts] = useState({ vehicles: 0, drivers: 0 });
  const [loading, setLoading] = useState(true);
  const [remarksMap, setRemarksMap] = useState({});
  const [busyId, setBusyId] = useState(null);

  const entityType = kind === "vehicles" ? "vehicle" : "driver";

  const refresh = async () => {
    setLoading(true);
    try {
      const [vq, dq] = await Promise.all([api.getQueue("vehicle"), api.getQueue("driver")]);
      setCounts({ vehicles: vq.items.length, drivers: dq.items.length });
      const raw = kind === "vehicles" ? vq.items : dq.items;
      const normalize = kind === "vehicles" ? normalizeVehicle : normalizeDriver;
      setQueue(raw.map((r) => ({ ...normalize(r), approvalLog: normalizeApprovalLog(r.approvalLog), actionable: r.actionable })));
    } catch (err) { onError(err); }
    setLoading(false);
  };
  useEffect(() => { refresh(); }, [kind]);

  const act = async (rec, action) => {
    const remarks = remarksMap[rec.id] || "";
    if ((action === "Reject" || action === "Send Back") && !remarks) { notify("Please add remarks before rejecting or sending back.", "red"); return; }
    setBusyId(rec.id);
    try {
      await api.decide(entityType, rec.id, action, remarks);
      notify(`${action === "Approve" ? "Approved" : action} — ${kind === "vehicles" ? rec.vehicleNumber : rec.name}`, action === "Reject" ? "red" : "green");
      setRemarksMap({ ...remarksMap, [rec.id]: "" });
      refresh();
    } catch (err) { onError(err); }
    setBusyId(null);
  };

  const resubmit = async (rec) => {
    setBusyId(rec.id);
    try {
      await api.resubmit(entityType, rec.id);
      notify("Resubmitted for approval from Safety stage.");
      refresh();
    } catch (err) { onError(err); }
    setBusyId(null);
  };

  return (
    <div>
      <PageHeader title="Approvals" subtitle={`Approval queue for ${role}. Stage order: ${APPROVAL_STAGES.join(" → ")}.`} />
      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        <Button tone={kind === "vehicles" ? "primary" : "default"} onClick={() => setKind("vehicles")} icon={Car}>Vehicles ({counts.vehicles})</Button>
        <Button tone={kind === "drivers" ? "primary" : "default"} onClick={() => setKind("drivers")} icon={Users}>Drivers ({counts.drivers})</Button>
      </div>

      {loading ? <Panel><p style={{ color: T.textFaint, fontSize: 13, textAlign: "center", padding: 20 }}>Loading…</p></Panel> :
        queue.length === 0 ? <Panel><p style={{ color: T.textFaint, fontSize: 13, textAlign: "center", padding: 20 }}>No items pending in this queue.</p></Panel> : null}

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {queue.map(rec => {
          const label = kind === "vehicles" ? rec.vehicleNumber : rec.name;
          const docsOk = overallDocStatus(rec.documents, kind === "vehicles" ? VEHICLE_DOC_TYPES : DRIVER_DOC_TYPES);
          const actionable = rec.actionable && rec.status !== "Sent Back";
          const busy = busyId === rec.id;
          return (
            <Panel key={rec.id}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10, flexWrap: "wrap", gap: 10 }}>
                <div>
                  <div style={{ fontFamily: "'Space Grotesk'", fontSize: 15, color: T.text, fontWeight: 600 }}>{label}</div>
                  <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2 }}>
                    {kind === "vehicles" ? `${rec.vehicleType} · ${rec.department} · ${rec.contractor}` : `${rec.contractor} · ${rec.mobile}`}
                  </div>
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <Badge tone={toneForStatus(rec.status)}>{rec.status}</Badge>
                  <Badge tone={toneForDocStatus(docsOk)}>Docs: {docsOk}</Badge>
                </div>
              </div>
              <ApprovalStepper currentStage={rec.currentStage} status={rec.status} log={rec.approvalLog} />
              {rec.status === "Sent Back" ? (
                <div style={{ marginTop: 14, padding: 10, background: T.amberDim, borderRadius: 7, fontSize: 12, color: T.amber }}>
                  Sent back: "{rec.approvalLog[rec.approvalLog.length - 1]?.remarks}" — awaiting resubmission.
                  {(role === "Contractor/User" || role === "System Administrator") && <div style={{ marginTop: 8 }}><Button tone="primary" icon={RotateCcw} onClick={() => resubmit(rec)} disabled={busy} style={busy ? { opacity: 0.6 } : {}}>Resubmit</Button></div>}
                </div>
              ) : (
                <div style={{ marginTop: 14 }}>
                  <TTextArea placeholder={`Remarks for ${APPROVAL_STAGES[rec.currentStage]} decision (required for reject/send back)`} value={remarksMap[rec.id] || ""} onChange={e => setRemarksMap({ ...remarksMap, [rec.id]: e.target.value })} />
                  <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                    <Button tone="green" icon={Check} disabled={!actionable || busy} onClick={() => act(rec, "Approve")} style={(!actionable || busy) ? { opacity: 0.4, cursor: "not-allowed" } : {}}>Approve</Button>
                    <Button tone="amber" icon={RotateCcw} disabled={!actionable || busy} onClick={() => act(rec, "Send Back")} style={(!actionable || busy) ? { opacity: 0.4, cursor: "not-allowed" } : { background: T.amberDim, color: T.amber, borderColor: T.amber }}>Send Back</Button>
                    <Button tone="red" icon={X} disabled={!actionable || busy} onClick={() => act(rec, "Reject")} style={(!actionable || busy) ? { opacity: 0.4, cursor: "not-allowed" } : {}}>Reject</Button>
                    {!actionable && <span style={{ fontSize: 11, color: T.textFaint, alignSelf: "center" }}>Waiting on {APPROVAL_STAGES[rec.currentStage]}</span>}
                  </div>
                </div>
              )}
            </Panel>
          );
        })}
      </div>
    </div>
  );
}


/* ============================== PASSES PAGE ============================== */
function PassesPage({ role, notify, onError }) {
  const [passes, setPasses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const { passes } = await api.getPasses();
        setPasses(passes.map(normalizeVehicle));
      } catch (err) { onError(err); }
      setLoading(false);
    })();
  }, []);

  return (
    <div>
      <PageHeader title="Vehicle Passes" subtitle="Digital passes generated after final Security HOD approval." />
      {loading ? <Panel><p style={{ color: T.textFaint, fontSize: 13 }}>Loading…</p></Panel> : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px,1fr))", gap: 16 }}>
          {passes.map(v => {
            const driver = v.driverName ? { name: v.driverName, emergencyContact: v.emergencyContact } : null;
            return (
              <div key={v.id} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <PassCard vehicle={v} driver={driver} />
                <div style={{ display: "flex", gap: 6 }}>
                  <Button icon={Printer} onClick={() => window.print()}>Print</Button>
                  <Button icon={Download} onClick={() => window.open(api.qrUrl(v.id), "_blank")}>QR Image</Button>
                  <Button icon={Mail} onClick={() => notify("Email delivery isn't wired up yet — export the QR image instead.")}>Email</Button>
                </div>
              </div>
            );
          })}
          {passes.length === 0 && <Panel><p style={{ color: T.textFaint, fontSize: 13 }}>No active passes yet.</p></Panel>}
        </div>
      )}
    </div>
  );
}


/* ============================== GATE / QR VERIFY PAGE ============================== */
function GatePage({ role, notify, onError }) {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [logging, setLogging] = useState(false);
  const [recentScans, setRecentScans] = useState([]);

  const loadScans = async () => {
    try { const { scans } = await api.getScans(); setRecentScans(scans); } catch (err) { onError(err); }
  };
  useEffect(() => { loadScans(); }, []);

  const verify = async () => {
    if (!query.trim()) return;
    setScanning(true);
    try {
      const data = await api.scan(query.trim());
      setResult({
        status: data.status,
        reason: data.reason,
        vehicle: data.vehicle ? normalizeVehicle(data.vehicle) : null,
        driver: data.driver ? normalizeDriver(data.driver) : null,
      });
      loadScans();
    } catch (err) { onError(err); }
    setScanning(false);
  };

  const logMovement = async (type) => {
    if (!result?.vehicle) return;
    setLogging(true);
    try {
      await api.logMovement(result.vehicle.vehicleNumber, type);
      notify(`${type} logged for ${result.vehicle.vehicleNumber}`);
    } catch (err) { onError(err); }
    setLogging(false);
  };

  const toneFor = { Valid: "green", Expired: "red", Blocked: "red", Invalid: "red" }[result?.status] || "dim";
  const IconFor = { Valid: CheckCircle2, Expired: Clock, Blocked: Ban, Invalid: XCircle }[result?.status] || ScanLine;

  return (
    <div>
      <PageHeader title="Gate / QR Verification" subtitle="Enter a Pass Number or Vehicle Number to simulate a QR scan at the gate." />
      <Panel style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <TInput placeholder="e.g. PB-10-AB-4521 or VAP-2026-0001" value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && verify()} />
          <Button tone="primary" icon={ScanLine} onClick={verify} disabled={scanning} style={scanning ? { opacity: 0.6 } : {}}>{scanning ? "Scanning…" : "Scan"}</Button>
        </div>
      </Panel>

      {result && (
        <Panel>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: 14, borderRadius: 8, marginBottom: 16, background: toneFor === "green" ? T.greenDim : T.redDim, border: `1px solid ${toneFor === "green" ? T.green : T.red}` }}>
            <IconFor size={22} color={toneFor === "green" ? T.green : T.red} />
            <div>
              <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 16, color: toneFor === "green" ? T.green : T.red }}>{result.status}</div>
              <div style={{ fontSize: 12, color: T.textDim }}>{result.reason}</div>
            </div>
          </div>

          {result.vehicle && (
            <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
              <PassCard vehicle={result.vehicle} driver={result.driver} />
              <div style={{ flex: 1, minWidth: 240 }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, fontSize: 12.5, marginBottom: 16 }}>
                  <InfoRow label="Approval Status" value={result.vehicle.status} />
                  <InfoRow label="Document Status" value={overallDocStatus(result.vehicle.documents, VEHICLE_DOC_TYPES)} />
                  <InfoRow label="Driver" value={result.driver?.name || "Not assigned"} />
                  <InfoRow label="Driver Status" value={result.driver ? (result.driver.blacklisted ? "Blacklisted" : "Clear") : "—"} />
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <Button tone="green" icon={DoorOpen} disabled={result.status !== "Valid" || logging} onClick={() => logMovement("Entry")} style={(result.status !== "Valid" || logging) ? { opacity: 0.4 } : {}}>Log Entry</Button>
                  <Button tone="amber" icon={DoorClosed} disabled={result.status !== "Valid" || logging} onClick={() => logMovement("Exit")} style={(result.status !== "Valid" || logging) ? { opacity: 0.4, background: T.amberDim, color: T.amber, borderColor: T.amber } : { background: T.amberDim, color: T.amber, borderColor: T.amber }}>Log Exit</Button>
                </div>
              </div>
            </div>
          )}
        </Panel>
      )}

      <Panel title="Recent Scans" style={{ marginTop: 16 }}>
        <DataTable columns={[
          { key: "ts", label: "Time", render: r => fmtDateTime(r.ts) },
          { key: "query", label: "Query" },
          { key: "result", label: "Result", render: r => <Badge tone={r.result === "Valid" ? "green" : "red"}>{r.result}</Badge> },
          { key: "by_name", label: "By" },
        ]} rows={recentScans.slice(0, 8)} />
      </Panel>
    </div>
  );
}


/* ============================== BLOCKLIST PAGE ============================== */
function BlocklistPage({ currentUser, notify, onError }) {
  const [tab, setTab] = useState("vehicles");
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [target, setTarget] = useState(null);
  const [reason, setReason] = useState(VEHICLE_BLOCK_REASONS[0]);
  const [remarks, setRemarks] = useState("");
  const [busy, setBusy] = useState(false);
  // Authorization is tied to a verified Security HOD account. The server enforces this
  // independently (requireRole middleware) - this check just controls what the UI offers.
  const canBlock = currentUser?.role === "Security HOD";

  const refresh = async () => {
    setLoading(true);
    try {
      const [v, d] = await Promise.all([api.getVehicles(), api.getDrivers()]);
      setVehicles(v.vehicles.map(normalizeVehicle));
      setDrivers(d.drivers.map(normalizeDriver));
    } catch (err) { onError(err); }
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const blockVehicle = async (v, blocked) => {
    setBusy(true);
    try {
      if (blocked) await api.blockVehicle(v.id, reason, remarks); else await api.unblockVehicle(v.id);
      notify(`${v.vehicleNumber} ${blocked ? "blocked" : "unblocked"}.`);
      setTarget(null); setRemarks(""); refresh();
    } catch (err) { onError(err); }
    setBusy(false);
  };
  const blockDriver = async (d, blacklisted) => {
    setBusy(true);
    try {
      if (blacklisted) await api.blacklistDriver(d.id, reason, remarks); else await api.unblacklistDriver(d.id);
      notify(`${d.name} ${blacklisted ? "blacklisted" : "unblacklisted"}.`);
      setTarget(null); setRemarks(""); refresh();
    } catch (err) { onError(err); }
    setBusy(false);
  };

  return (
    <div>
      <PageHeader title="Block / Blacklist" subtitle={canBlock ? `Signed in as verified Security HOD — ${currentUser.name} (${currentUser.empId}) can authorize actions below.` : "Only a verified Security HOD account can authorize vehicle blocking or driver blacklisting. You have view-only access."} />
      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        <Button tone={tab === "vehicles" ? "primary" : "default"} icon={Car} onClick={() => setTab("vehicles")}>Vehicles</Button>
        <Button tone={tab === "drivers" ? "primary" : "default"} icon={Users} onClick={() => setTab("drivers")}>Drivers</Button>
      </div>

      {loading ? <Panel><p style={{ color: T.textFaint, fontSize: 13 }}>Loading…</p></Panel> : tab === "vehicles" ? (
        <Panel>
          <DataTable columns={[
            { key: "vehicleNumber", label: "Vehicle" }, { key: "contractor", label: "Contractor" },
            { key: "blocked", label: "Status", render: r => r.blocked ? <Badge tone="red">Blocked — {r.blockInfo?.reason}</Badge> : <Badge tone="green">Active</Badge> },
            { key: "actions", label: "", render: r => canBlock ? (
              r.blocked ? <Button tone="green" onClick={() => blockVehicle(r, false)} disabled={busy}>Unblock</Button> : <Button tone="red" onClick={() => { setTarget(r); setReason(VEHICLE_BLOCK_REASONS[0]); }}>Block</Button>
            ) : <span style={{ color: T.textFaint, fontSize: 11 }}>View only</span> },
          ]} rows={vehicles} />
        </Panel>
      ) : (
        <Panel>
          <DataTable columns={[
            { key: "name", label: "Driver" }, { key: "contractor", label: "Contractor" },
            { key: "blacklisted", label: "Status", render: r => r.blacklisted ? <Badge tone="red">Blacklisted — {r.blacklistInfo?.reason}</Badge> : <Badge tone="green">Clear</Badge> },
            { key: "actions", label: "", render: r => canBlock ? (
              r.blacklisted ? <Button tone="green" onClick={() => blockDriver(r, false)} disabled={busy}>Unblacklist</Button> : <Button tone="red" onClick={() => { setTarget(r); setReason(DRIVER_BLOCK_REASONS[0]); }}>Blacklist</Button>
            ) : <span style={{ color: T.textFaint, fontSize: 11 }}>View only</span> },
          ]} rows={drivers} />
        </Panel>
      )}

      {target && (
        <Modal title={`${tab === "vehicles" ? "Block Vehicle" : "Blacklist Driver"} — ${tab === "vehicles" ? target.vehicleNumber : target.name}`} onClose={() => setTarget(null)} width={480}>
          <Field label="Reason">
            <TSelect value={reason} onChange={e => setReason(e.target.value)}>
              {(tab === "vehicles" ? VEHICLE_BLOCK_REASONS : DRIVER_BLOCK_REASONS).map(r => <option key={r}>{r}</option>)}
            </TSelect>
          </Field>
          <div style={{ height: 10 }} />
          <Field label="Remarks"><TTextArea value={remarks} onChange={e => setRemarks(e.target.value)} placeholder="Additional details..." /></Field>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 16 }}>
            <Button onClick={() => setTarget(null)}>Cancel</Button>
            <Button tone="red" disabled={busy} onClick={() => tab === "vehicles" ? blockVehicle(target, true) : blockDriver(target, true)}>Confirm</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}


/* ============================== REPORTS PAGE ============================== */
function ReportsPage({ onError }) {
  const [tab, setTab] = useState("vehicle");
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [logs, setLogs] = useState([]);
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const [v, d, l, s] = await Promise.all([api.getVehicles(), api.getDrivers(), api.getLogs(), api.getScans()]);
        setVehicles(v.vehicles.map(normalizeVehicle));
        setDrivers(d.drivers.map(normalizeDriver));
        setLogs(l.logs);
        setScans(s.scans);
      } catch (err) { onError(err); }
      setLoading(false);
    })();
  }, []);

  const tabs = [
    { key: "vehicle", label: "Vehicle Reports" }, { key: "driver", label: "Driver Reports" },
    { key: "blocklist", label: "Blocklist Reports" }, { key: "approval", label: "Approval Reports" }, { key: "gate", label: "Gate Reports" },
  ];

  if (loading) return <div style={{ color: T.textFaint, fontSize: 13, padding: 30 }}>Loading reports…</div>;

  return (
    <div>
      <PageHeader title="Reports" subtitle="Operational reports across vehicles, drivers, approvals and gate activity." />
      <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
        {tabs.map(t => <Button key={t.key} tone={tab === t.key ? "primary" : "default"} onClick={() => setTab(t.key)}>{t.label}</Button>)}
      </div>
      {tab === "vehicle" && (
        <Panel title={`Registered Vehicles (${vehicles.length})`}>
          <DataTable columns={[
            { key: "vehicleNumber", label: "Vehicle" }, { key: "vehicleType", label: "Type" }, { key: "department", label: "Department" },
            { key: "contractor", label: "Contractor" }, { key: "status", label: "Status", render: r => <Badge tone={toneForStatus(r.status)}>{r.status}</Badge> },
            { key: "docs", label: "Docs", render: r => <Badge tone={toneForDocStatus(overallDocStatus(r.documents, VEHICLE_DOC_TYPES))}>{overallDocStatus(r.documents, VEHICLE_DOC_TYPES)}</Badge> },
          ]} rows={vehicles} />
        </Panel>
      )}
      {tab === "driver" && (
        <Panel title={`Registered Drivers (${drivers.length})`}>
          <DataTable columns={[
            { key: "name", label: "Name" }, { key: "mobile", label: "Mobile" }, { key: "contractor", label: "Contractor" },
            { key: "licence", label: "Licence Expiry", render: r => fmtDate(r.documents?.["Driving Licence"]?.expiryDate) },
            { key: "training", label: "Training Expiry", render: r => fmtDate(r.documents?.["VDSS Training Certificate"]?.expiryDate) },
            { key: "status", label: "Status", render: r => <Badge tone={toneForStatus(r.status)}>{r.status}</Badge> },
          ]} rows={drivers} />
        </Panel>
      )}
      {tab === "blocklist" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <Panel title="Blocked Vehicles"><DataTable columns={[{ key: "vehicleNumber", label: "Vehicle" }, { key: "reason", label: "Reason", render: r => r.blockInfo?.reason }, { key: "by", label: "By", render: r => r.blockInfo?.by }, { key: "date", label: "Date", render: r => fmtDate(r.blockInfo?.date) }]} rows={vehicles.filter(v => v.blocked)} /></Panel>
          <Panel title="Blacklisted Drivers"><DataTable columns={[{ key: "name", label: "Driver" }, { key: "reason", label: "Reason", render: r => r.blacklistInfo?.reason }, { key: "by", label: "By", render: r => r.blacklistInfo?.by }, { key: "date", label: "Date", render: r => fmtDate(r.blacklistInfo?.date) }]} rows={drivers.filter(d => d.blacklisted)} /></Panel>
        </div>
      )}
      {tab === "approval" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {["Pending", "Approved", "Rejected", "Sent Back"].map(st => (
            <Panel key={st} title={`${st} (${vehicles.filter(v => v.status === st).length + drivers.filter(d => d.status === st).length})`}>
              <DataTable columns={[{ key: "item", label: "Item" }, { key: "type", label: "Type" }, { key: "stage", label: "Current Stage" }]} rows={[
                ...vehicles.filter(v => v.status === st).map(v => ({ id: v.id, item: v.vehicleNumber, type: "Vehicle", stage: APPROVAL_STAGES[v.currentStage] || "—" })),
                ...drivers.filter(d => d.status === st).map(d => ({ id: d.id, item: d.name, type: "Driver", stage: APPROVAL_STAGES[d.currentStage] || "—" })),
              ]} />
            </Panel>
          ))}
        </div>
      )}
      {tab === "gate" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <Panel title="Entry / Exit Log"><DataTable columns={[{ key: "ts", label: "Time", render: r => fmtDateTime(r.ts) }, { key: "vehicle_number", label: "Vehicle" }, { key: "type", label: "Type", render: r => <Badge tone={r.type === "Entry" ? "green" : "amber"}>{r.type}</Badge> }, { key: "gate", label: "Gate" }, { key: "by_name", label: "By" }]} rows={logs} /></Panel>
          <Panel title="QR Scan Log"><DataTable columns={[{ key: "ts", label: "Time", render: r => fmtDateTime(r.ts) }, { key: "query", label: "Query" }, { key: "result", label: "Result", render: r => <Badge tone={r.result === "Valid" ? "green" : "red"}>{r.result}</Badge> }, { key: "by_name", label: "By" }]} rows={scans} /></Panel>
        </div>
      )}
    </div>
  );
}


/* ============================== ADMIN PAGE ============================== */
function emptyUser() {
  return { name: "", empId: "", department: "", designation: "", email: "", mobile: "", username: "", password: "", role: ROLES[0], status: "Active" };
}

function AdminPage({ role, notify, onError }) {
  const [tab, setTab] = useState("masters");
  const [masterKey, setMasterKey] = useState("departments");
  const [masters, setMasters] = useState({ departments: [], contractors: [], companies: [], vehicleTypes: [] });
  const [newVal, setNewVal] = useState("");
  const [users, setUsers] = useState([]);
  const [auditLog, setAuditLog] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showUserForm, setShowUserForm] = useState(false);
  const [userForm, setUserForm] = useState(emptyUser());
  const [saving, setSaving] = useState(false);

  const loadMasters = async () => { try { setMasters(await api.getMasters()); } catch (err) { onError(err); } };
  const loadUsers = async () => { try { const { users } = await api.getUsers(); setUsers(users.map(normalizeUser)); } catch (err) { onError(err); } };
  const loadAudit = async () => { try { const { auditLog } = await api.getAudit(); setAuditLog(auditLog); } catch (err) { onError(err); } };

  useEffect(() => {
    (async () => {
      setLoading(true);
      await Promise.all([loadMasters(), loadUsers().catch(() => {}), loadAudit().catch(() => {})]);
      setLoading(false);
    })();
  }, []);

  const currentList = masters[masterKey] || [];

  const addMaster = async () => {
    if (!newVal.trim()) return;
    try {
      await api.addMaster(masterKey, newVal.trim());
      setNewVal(""); notify("Added to " + masterKey);
      loadMasters();
    } catch (err) { onError(err); }
  };
  const removeMaster = async (val) => {
    try { await api.removeMaster(masterKey, val); loadMasters(); } catch (err) { onError(err); }
  };

  const saveUser = async () => {
    if (!userForm.name || !userForm.empId || !userForm.username || !userForm.password) { notify("Name, Employee ID, Username and Password are required.", "red"); return; }
    setSaving(true);
    try {
      await api.addUser(userForm);
      notify(`${userForm.name} added as ${userForm.role}.`);
      setShowUserForm(false); setUserForm(emptyUser());
      loadUsers();
    } catch (err) { onError(err); }
    setSaving(false);
  };

  const masterLabels = { departments: "Department Master", contractors: "Contractor Master", companies: "Company Master", vehicleTypes: "Vehicle Type Master" };

  return (
    <div>
      <PageHeader title="Admin" subtitle="Master data, user management and system audit trail." />
      <div style={{ display: "flex", gap: 6, marginBottom: 14 }}>
        <Button tone={tab === "masters" ? "primary" : "default"} icon={ListChecks} onClick={() => setTab("masters")}>Masters</Button>
        <Button tone={tab === "users" ? "primary" : "default"} icon={Users} onClick={() => setTab("users")}>Users</Button>
        <Button tone={tab === "audit" ? "primary" : "default"} icon={FileBarChart2} onClick={() => setTab("audit")}>Audit Log</Button>
      </div>

      {loading ? <Panel><p style={{ color: T.textFaint, fontSize: 13 }}>Loading…</p></Panel> : (
        <>
          {tab === "masters" && (
            <div className="grid-3" style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 14 }}>
              <Panel>
                {Object.keys(masterLabels).map(k => (
                  <button key={k} onClick={() => setMasterKey(k)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", textAlign: "left", padding: "9px 10px", marginBottom: 3, borderRadius: 6, background: masterKey === k ? T.amberDim : "transparent", color: masterKey === k ? T.amber : T.textDim, border: "none", cursor: "pointer", fontSize: 12.5 }}><Building2 size={14} />{masterLabels[k]}</button>
                ))}
              </Panel>
              <Panel title={masterLabels[masterKey]}>
                <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
                  <TInput value={newVal} onChange={e => setNewVal(e.target.value)} placeholder="Add new entry..." onKeyDown={e => e.key === "Enter" && addMaster()} />
                  <Button tone="primary" icon={Plus} onClick={addMaster}>Add</Button>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {currentList.map(v => (
                    <div key={v} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 10px", background: T.panel2, borderRadius: 6, fontSize: 12.5 }}>
                      {v}<button onClick={() => removeMaster(v)} style={{ background: "none", border: "none", color: T.textFaint, cursor: "pointer" }}><Trash2 size={14} /></button>
                    </div>
                  ))}
                </div>
              </Panel>
            </div>
          )}

          {tab === "users" && (
            <Panel title={`System Users (${users.length})`} right={<Button tone="primary" icon={Plus} onClick={() => { setUserForm(emptyUser()); setShowUserForm(true); }}>Add User</Button>}>
              <DataTable columns={[
                { key: "name", label: "Name" }, { key: "empId", label: "Employee ID" }, { key: "department", label: "Department" },
                { key: "username", label: "Username" },
                { key: "role", label: "Role", render: r => <Badge tone="blue">{r.role}</Badge> },
                { key: "status", label: "Status", render: r => <Badge tone={r.status === "Active" ? "green" : "red"}>{r.status}</Badge> },
              ]} rows={users} />
            </Panel>
          )}

          {tab === "audit" && (
            <Panel title="Audit Log">
              <DataTable columns={[{ key: "ts", label: "Time", render: r => fmtDateTime(r.ts) }, { key: "by_name", label: "By" }, { key: "action", label: "Action" }, { key: "details", label: "Details" }]} rows={auditLog} />
            </Panel>
          )}
        </>
      )}

      {showUserForm && (
        <Modal title="Register New User" onClose={() => setShowUserForm(false)} width={640}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <Field label="Employee Name *"><TInput value={userForm.name} onChange={e => setUserForm({ ...userForm, name: e.target.value })} /></Field>
            <Field label="Employee ID *"><TInput value={userForm.empId} onChange={e => setUserForm({ ...userForm, empId: e.target.value })} placeholder="EMP-1003" /></Field>
            <Field label="Department">
              <TSelect value={userForm.department} onChange={e => setUserForm({ ...userForm, department: e.target.value })}><option value="">Select</option>{masters.departments.map(v => <option key={v}>{v}</option>)}</TSelect>
            </Field>
            <Field label="Designation"><TInput value={userForm.designation} onChange={e => setUserForm({ ...userForm, designation: e.target.value })} /></Field>
            <Field label="Email"><TInput type="email" value={userForm.email} onChange={e => setUserForm({ ...userForm, email: e.target.value })} /></Field>
            <Field label="Mobile Number"><TInput value={userForm.mobile} onChange={e => setUserForm({ ...userForm, mobile: e.target.value })} /></Field>
            <Field label="Username *"><TInput value={userForm.username} onChange={e => setUserForm({ ...userForm, username: e.target.value })} placeholder="e.g. jane.doe" /></Field>
            <Field label="Password * (min 8 chars)"><TInput type="password" value={userForm.password} onChange={e => setUserForm({ ...userForm, password: e.target.value })} /></Field>
            <Field label="Role">
              <TSelect value={userForm.role} onChange={e => setUserForm({ ...userForm, role: e.target.value })}>{ROLES.map(r => <option key={r}>{r}</option>)}</TSelect>
            </Field>
            <Field label="Status">
              <TSelect value={userForm.status} onChange={e => setUserForm({ ...userForm, status: e.target.value })}><option>Active</option><option>Inactive</option></TSelect>
            </Field>
          </div>
          {userForm.role === "Security HOD" && (
            <div style={{ marginTop: 12, fontSize: 11.5, color: T.amber, background: T.amberDim, padding: "8px 10px", borderRadius: 6 }}>
              This account will be able to sign in to authorize Block / Blacklist actions — enforced by the server, not just the UI.
            </div>
          )}
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 18 }}>
            <Button onClick={() => setShowUserForm(false)}>Cancel</Button>
            <Button tone="primary" onClick={saveUser} disabled={saving} style={saving ? { opacity: 0.6 } : {}}>{saving ? "Saving…" : "Save User"}</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}
